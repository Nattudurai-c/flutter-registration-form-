// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'province.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProvinceEntity _$ProvinceEntityFromJson(Map<String, dynamic> json) {
  return ProvinceEntity(
    id: json['id'] as int,
    name: json['nama'] as String,
  );
}

Map<String, dynamic> _$ProvinceEntityToJson(ProvinceEntity instance) =>
    <String, dynamic>{
      'id': instance.id,
      'nama': instance.name,
    };
