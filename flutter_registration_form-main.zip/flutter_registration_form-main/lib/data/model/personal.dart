class Personal {
  final String ktpId;
  final String name;
  final String accountNumber;
  final String educationLevel;
  final String dob;

  Personal(
      {this.ktpId,
      this.name,
      this.accountNumber,
      this.educationLevel,
      this.dob});
}
