class KtpAddress {
  final String provinse;
  final String residence;
  final String blockNumber;
  final String fullAddress;

  KtpAddress(
      {this.provinse, this.residence, this.blockNumber, this.fullAddress});
}
