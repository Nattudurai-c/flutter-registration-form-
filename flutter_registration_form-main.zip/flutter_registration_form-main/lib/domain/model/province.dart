class Province {
  final int id;
  final String name;

  Province({this.id: -1, this.name: ""});
}
