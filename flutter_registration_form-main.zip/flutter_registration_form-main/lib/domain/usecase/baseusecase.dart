abstract class BaseUseCase<T> {
  execute({T params});
}
