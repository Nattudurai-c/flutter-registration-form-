/// Status of a resource that is provided to the UI.
///
///
enum Status { SUCCESS, ERROR, LOADING }
