import 'package:registration_form/app/base/base_vm.dart';
import 'package:registration_form/app/feature/reviewdata/ktpaddressdata_view.dart';

class ReviewDataVM extends BaseVM {
  final ReviewDataViewParams params;

  ReviewDataVM(this.params);
}
